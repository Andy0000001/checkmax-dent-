<?php

//В переменную $token нужно вставить токен, который нам прислал @botFather
$token = "5737881814:AAHU2Plw9ANAhpCCNnhS-i-PvoURxrx-Pes";

//Сюда вставляем chat_id
$chat_id = "-889536273";

//Определяем переменные для передачи данных из нашей формы
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = ($_POST['name']);
    $phone = ($_POST['phone']);

//Собираем в массив то, что будет передаваться боту
    $arr = array(
        'Имя:' => $name,
        'Телефон:' => $phone
    );

//Настраиваем внешний вид сообщения в телеграме
    foreach($arr as $key => $value) {
        $txt .= "<b>".$key."</b> ".$value."%0A";
    };

//Передаем данные боту
    $sendToTelegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}","r");
  };

  header("Location:./orto-dent-main.html");
?>