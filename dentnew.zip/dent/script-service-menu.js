document.querySelector("#list").addEventListener('click', viewList);
document.querySelector("#close1").addEventListener('click', closeList);

function viewList(){
  document.querySelector(".dropdown__list").style.display = "block";
}

function closeList(){
    document.querySelector(".dropdown__list").style.display = "none";
}

const serlist = document.querySelector("#close1");

const serv = document.querySelector("#list");

const uslist = document.querySelector("#close2");

const us = document.querySelector("#list-us");

us.onmouseenter = haderUs;
uslist.onmouseleave = haderUs1;

function haderUs(event){
  if (event.type = "mouseenter"){
    uslist.style.display = "block"
    serlist.style.display = "none"
  }
}

function haderUs1(event){
  if (event.type = "mouseleave"){
    uslist.style.display = "none"
  }
}

serv.onmouseenter = haderServ;
serlist.onmouseleave = haderServ1;

function haderServ(event){
  if (event.type = "mouseenter"){
    serlist.style.display = "block"
    uslist.style.display = "none"
  }
}

function haderServ1(event){
  if (event.type = "mouseleave"){
    serlist.style.display = "none"
  }
}
